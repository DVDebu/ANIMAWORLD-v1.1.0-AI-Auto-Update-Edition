# 🌍 ANIMAWORLD — Desktop & Mobile Apps Launch Guide

## 📦 What's in This Package

```
animaworld-apps/
├── 🖥  electron/          Mac + Windows + Linux desktop app
├── 📱  android/           Android APK project
├── 🌐  web/               Pre-built website (deploy to Netlify/Vercel)
└── 📖  README.md          This file
```

---

## 🍎 MAC APP — Build & Launch

### Requirements
- macOS 11+ (Big Sur or later)
- Node.js 18+ → https://nodejs.org
- 5 minutes

### Steps

```bash
# 1. Go into the electron folder
cd electron

# 2. Install dependencies
npm install

# 3. Test it locally (runs the app)
npm start

# 4. Build the .dmg installer for Mac
npm run dist:mac
```

The `.dmg` file appears in `electron/dist/` — double-click it, drag AnimaWorld to Applications. Done! 🎉

### What you get:
- ✅ Native Mac app with proper menu bar (Cmd+1-5 navigation)
- ✅ AnimaWorld icon in dock and Applications folder
- ✅ Cmd+F to search anime
- ✅ Native About dialog with version info
- ✅ Proper window sizing, full-screen support
- ✅ External links open in browser
- ✅ macOS dark mode support
- ✅ Arm64 + x64 universal binary (Apple Silicon + Intel)

---

## 🤖 ANDROID APP — Build & Install

### Requirements
- Android Studio (free) → https://developer.android.com/studio
- JDK 17+ (bundled with Android Studio)
- Android device or emulator with Android 7.0+

### Steps

```
1. Open Android Studio
2. Click "Open an Existing Project"
3. Select the "android" folder from this zip
4. Wait for Gradle sync (1-2 minutes, downloads dependencies)
5. Click the green ▶ Run button
6. Select your device or emulator
7. App installs and launches automatically!
```

### Build a Release APK (for sharing / Play Store)

```
In Android Studio:
Build → Generate Signed Bundle/APK → APK → Create new keystore
→ Choose Release → Build
```

APK saved to: `android/app/release/app-release.apk`

### Install directly on Android phone (no Play Store)

```bash
# Enable USB debugging on your phone (Settings → Developer Options)
# Connect via USB, then:
adb install android/app/release/app-release.apk
```

### What you get:
- ✅ Native Android app with custom launcher icon
- ✅ Full-screen immersive experience
- ✅ Hardware-accelerated WebView
- ✅ Native share button (share anime to WhatsApp, Instagram, etc.)
- ✅ External links open in Chrome/browser
- ✅ Back button navigation
- ✅ Saves your anime list in local storage
- ✅ Works offline (loads from bundled assets)
- ✅ Deep links: animaworld:// and https://animaworld.app

---

## 🌐 WEBSITE — Deploy in 60 seconds

```
1. Go to https://app.netlify.com/drop
2. Drag the web/dist/ folder onto the page
3. Live at: your-site.netlify.app  🎉
```

Or with Vercel:
```bash
cd web && npx vercel --prod
```

---

## 🚀 Publish to Stores (Next Level)

### Google Play Store
1. Build a signed AAB: `Build → Generate Signed Bundle/APK → Android App Bundle`
2. Go to https://play.google.com/console
3. Create app → Upload AAB → Fill details → Publish
4. Review takes 1-3 days

### Mac App Store
```bash
# Requires Apple Developer account ($99/year)
# In electron folder:
npm run dist:mac
# Upload .pkg to App Store Connect
```

### Microsoft Store (Windows)
```bash
cd electron && npm run dist:win
# Submit the .msix to https://partner.microsoft.com/dashboard
```

---

## 🎨 Customization

To update the app content, edit `electron/dist/assets/` or `android/app/src/main/assets/`
and rebuild following the steps above.

To add more anime, edit the `ANIME_DB` array in the React source (`web/src/App.jsx`),
run `npm run build` in the web folder, then copy the new `dist/` to both apps.

---

Built with ❤️ | AnimaWorld v1.0.0 | React + Vite + Electron + Android WebView
