const { contextBridge, ipcRenderer } = require('electron');

// Expose safe APIs to the renderer process
contextBridge.exposeInMainWorld('electronAPI', {
  // Navigation
  onNav: (callback) => ipcRenderer.on('nav', (_, tab) => callback(tab)),
  onFocusSearch: (callback) => ipcRenderer.on('focus-search', () => callback()),
  onOpenSettings: (callback) => ipcRenderer.on('open-settings', () => callback()),

  // App info
  getVersion: () => ipcRenderer.invoke('get-app-version'),
  getPlatform: () => ipcRenderer.invoke('get-platform'),

  // Open external links
  openExternal: (url) => ipcRenderer.send('open-external', url),

  // Storage — persists across app sessions
  storage: {
    get: (key) => {
      try {
        const val = localStorage.getItem(key);
        return val ? { key, value: val } : null;
      } catch { return null; }
    },
    set: (key, value) => {
      try {
        localStorage.setItem(key, value);
        return { key, value };
      } catch { return null; }
    },
    delete: (key) => {
      try {
        localStorage.removeItem(key);
        return { key, deleted: true };
      } catch { return null; }
    },
    list: (prefix = '') => {
      const keys = Object.keys(localStorage).filter(k => k.startsWith(prefix));
      return { keys };
    }
  }
});
