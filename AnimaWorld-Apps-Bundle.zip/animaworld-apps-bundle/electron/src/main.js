const { app, BrowserWindow, Menu, shell, Tray, nativeImage, ipcMain, dialog, nativeTheme } = require('electron');
const path = require('path');
const url = require('url');

// ── Constants ────────────────────────────────────────────────────────────────
const APP_NAME = 'AnimaWorld';
const APP_VERSION = '1.0.0';
const WEBSITE_URL = 'https://animaworld.app';
const isDev = process.env.NODE_ENV === 'development';

let mainWindow = null;
let tray = null;
let isQuitting = false;

// ── Single Instance Lock ─────────────────────────────────────────────────────
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}

// ── App Config ───────────────────────────────────────────────────────────────
app.setName(APP_NAME);
if (process.platform === 'darwin') {
  app.dock?.setIcon(path.join(__dirname, '../assets/icon.png'));
}

// ── Create Window ────────────────────────────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    title: APP_NAME,
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    trafficLightPosition: { x: 18, y: 18 },
    backgroundColor: '#040810',
    icon: path.join(__dirname, '../assets/icon.png'),
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      webSecurity: true,
    },
  });

  // Load the built React app
  const appUrl = isDev
    ? 'http://localhost:5173'
    : url.format({ pathname: path.join(__dirname, '../dist/index.html'), protocol: 'file:', slashes: true });

  mainWindow.loadURL(appUrl);

  // Smooth show once ready
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (isDev) mainWindow.webContents.openDevTools();
  });

  // Handle close — minimize to tray on Windows/Linux, quit on Mac
  mainWindow.on('close', (e) => {
    if (!isQuitting && process.platform !== 'darwin') {
      e.preventDefault();
      mainWindow.hide();
    }
  });

  // Open external links in browser
  mainWindow.webContents.setWindowOpenHandler(({ url: linkUrl }) => {
    if (linkUrl.startsWith('http')) {
      shell.openExternal(linkUrl);
      return { action: 'deny' };
    }
    return { action: 'allow' };
  });

  // Prevent navigation away from app
  mainWindow.webContents.on('will-navigate', (e, navUrl) => {
    if (!navUrl.startsWith('file://') && !navUrl.startsWith('http://localhost')) {
      e.preventDefault();
      shell.openExternal(navUrl);
    }
  });

  return mainWindow;
}

// ── System Tray (Windows/Linux) ──────────────────────────────────────────────
function createTray() {
  if (process.platform === 'darwin') return; // Mac uses dock

  const trayIcon = nativeImage.createFromPath(path.join(__dirname, '../assets/tray.png'));
  tray = new Tray(trayIcon.resize({ width: 16, height: 16 }));
  tray.setToolTip(APP_NAME);
  tray.setTitle(APP_NAME);

  tray.setContextMenu(Menu.buildFromTemplate([
    { label: '🌍 AnimaWorld', enabled: false },
    { type: 'separator' },
    { label: 'Open App', click: () => { mainWindow?.show(); mainWindow?.focus(); } },
    { label: 'Trending Now', click: () => { mainWindow?.show(); mainWindow?.webContents.send('nav', 'trending'); } },
    { label: 'World Rankings', click: () => { mainWindow?.show(); mainWindow?.webContents.send('nav', 'rankings'); } },
    { type: 'separator' },
    { label: 'Quit', click: () => { isQuitting = true; app.quit(); } },
  ]));

  tray.on('double-click', () => { mainWindow?.show(); mainWindow?.focus(); });
}

// ── Native Menu ──────────────────────────────────────────────────────────────
function buildMenu() {
  const isMac = process.platform === 'darwin';

  const template = [
    ...(isMac ? [{
      label: APP_NAME,
      submenu: [
        { label: `About ${APP_NAME}`, click: showAbout },
        { type: 'separator' },
        { label: 'Preferences...', accelerator: 'Cmd+,', click: () => mainWindow?.webContents.send('open-settings') },
        { type: 'separator' },
        { role: 'services' },
        { type: 'separator' },
        { role: 'hide' },
        { role: 'hideOthers' },
        { role: 'unhide' },
        { type: 'separator' },
        { role: 'quit' },
      ],
    }] : []),
    {
      label: '📺 Anime',
      submenu: [
        { label: '🌍 World Rankings', accelerator: 'CmdOrCtrl+1', click: () => mainWindow?.webContents.send('nav', 'rankings') },
        { label: '🆕 New Releases', accelerator: 'CmdOrCtrl+2', click: () => mainWindow?.webContents.send('nav', 'new') },
        { label: '🔥 Trending', accelerator: 'CmdOrCtrl+3', click: () => mainWindow?.webContents.send('nav', 'trending') },
        { label: '📺 Social Hub', accelerator: 'CmdOrCtrl+4', click: () => mainWindow?.webContents.send('nav', 'social') },
        { label: '🔍 All Anime', accelerator: 'CmdOrCtrl+5', click: () => mainWindow?.webContents.send('nav', 'all') },
        { type: 'separator' },
        { label: '🔍 Search...', accelerator: 'CmdOrCtrl+F', click: () => mainWindow?.webContents.send('focus-search') },
      ],
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' },
        { type: 'separator' },
        {
          label: 'Toggle Dark/Light Mode',
          accelerator: 'CmdOrCtrl+Shift+T',
          click: () => {
            nativeTheme.themeSource = nativeTheme.shouldUseDarkColors ? 'light' : 'dark';
          }
        },
        ...(isDev ? [{ type: 'separator' }, { role: 'toggleDevTools' }] : []),
      ],
    },
    {
      label: 'Window',
      submenu: [
        { role: 'minimize' },
        { role: 'zoom' },
        ...(isMac ? [{ type: 'separator' }, { role: 'front' }] : []),
        { type: 'separator' },
        { label: 'Bring to Front', accelerator: 'CmdOrCtrl+Shift+F', click: () => { mainWindow?.show(); mainWindow?.focus(); } },
      ],
    },
    {
      label: 'Help',
      submenu: [
        { label: `${APP_NAME} v${APP_VERSION}`, enabled: false },
        { type: 'separator' },
        { label: '🌍 Visit Website', click: () => shell.openExternal(WEBSITE_URL) },
        { label: '📺 YouTube Channel', click: () => shell.openExternal('https://youtube.com/results?search_query=animaworld') },
        { label: '𝕏 Follow on X', click: () => shell.openExternal('https://twitter.com/intent/follow?screen_name=AnimaWorld') },
        { label: '● Reddit Community', click: () => shell.openExternal('https://reddit.com/r/anime') },
        { type: 'separator' },
        ...(!isMac ? [{ label: `About ${APP_NAME}`, click: showAbout }] : []),
      ],
    },
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

function showAbout() {
  dialog.showMessageBox(mainWindow, {
    type: 'info',
    icon: path.join(__dirname, '../assets/icon.png'),
    title: `About ${APP_NAME}`,
    message: APP_NAME,
    detail: `Version ${APP_VERSION}\n\nThe world's #1 global anime discovery platform.\n\nDiscover, track and share the best anime across all platforms.\n\n© ${new Date().getFullYear()} AnimaWorld. All rights reserved.`,
    buttons: ['Visit Website', 'Close'],
    defaultId: 1,
  }).then(result => {
    if (result.response === 0) shell.openExternal(WEBSITE_URL);
  });
}

// ── IPC Handlers ─────────────────────────────────────────────────────────────
ipcMain.handle('get-app-version', () => APP_VERSION);
ipcMain.handle('get-platform', () => process.platform);
ipcMain.on('open-external', (_, url) => shell.openExternal(url));

// ── App Events ───────────────────────────────────────────────────────────────
app.whenReady().then(() => {
  createWindow();
  buildMenu();
  createTray();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
    else mainWindow?.show();
  });
});

app.on('before-quit', () => { isQuitting = true; });

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
