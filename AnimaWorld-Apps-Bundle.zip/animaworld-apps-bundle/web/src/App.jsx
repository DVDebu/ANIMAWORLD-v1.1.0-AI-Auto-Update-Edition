import { useState, useEffect, useRef } from "react";

// ─── COMPREHENSIVE WORLD ANIME DATABASE ─────────────────────────────────────
const ANIME_DB = [
  {
    id: 1, rank: 1, title: "Frieren: Beyond Journey's End", titleJP: "葬送のフリーレン",
    score: 9.38, members: 2100000, episodes: 28, status: "Finished", season: "Fall 2023",
    studio: "Madhouse", genre: ["Fantasy","Adventure","Drama"], year: 2023,
    synopsis: "After the party of heroes defeats the Demon King, the elven mage Frieren begins a journey to understand humanity — reflecting on her 1,000 years of life.",
    cover: "https://picsum.photos/seed/frieren2024/400/560",
    banner: "https://picsum.photos/seed/frierenbanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=dLkGTFHW-Mc",
    ytSearch: "https://www.youtube.com/results?search_query=Frieren+Beyond+Journey%27s+End+official+trailer",
    social: {
      mal: "https://myanimelist.net/anime/52991",
      anilist: "https://anilist.co/anime/145139",
      twitter: "https://twitter.com/search?q=Frieren+anime",
      instagram: "https://www.instagram.com/explore/tags/frieren/",
      tiktok: "https://www.tiktok.com/search?q=Frieren+anime",
      facebook: "https://www.facebook.com/search/top?q=Frieren+anime",
      reddit: "https://www.reddit.com/r/anime/search/?q=Frieren",
      youtube: "https://www.youtube.com/@frieren_anime",
    },
    trending: true, newRelease: false, featured: true,
    badge: "🏆 #1 Worldwide", color: "#c8a4ff",
  },
  {
    id: 2, rank: 2, title: "Fullmetal Alchemist: Brotherhood", titleJP: "鋼の錬金術師",
    score: 9.10, members: 3500000, episodes: 64, status: "Finished", season: "Spring 2009",
    studio: "Bones", genre: ["Action","Adventure","Fantasy"], year: 2009,
    synopsis: "Two brothers search for the Philosopher's Stone after a failed attempt to resurrect their mother leaves them scarred.",
    cover: "https://picsum.photos/seed/fma2009/400/560",
    banner: "https://picsum.photos/seed/fmabanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=--IcmZkvL0Q",
    ytSearch: "https://www.youtube.com/results?search_query=Fullmetal+Alchemist+Brotherhood+trailer",
    social: {
      mal: "https://myanimelist.net/anime/5114",
      anilist: "https://anilist.co/anime/5114",
      twitter: "https://twitter.com/search?q=FMA+Brotherhood",
      instagram: "https://www.instagram.com/explore/tags/fullmetalalchemist/",
      tiktok: "https://www.tiktok.com/search?q=FMA+Brotherhood",
      facebook: "https://www.facebook.com/search/top?q=Fullmetal+Alchemist+Brotherhood",
      reddit: "https://www.reddit.com/r/FullmetalAlchemist/",
      youtube: "https://www.youtube.com/results?search_query=FMAB+official",
    },
    trending: false, newRelease: false, featured: false,
    badge: "👑 All-Time Legend", color: "#ffd966",
  },
  {
    id: 3, rank: 3, title: "Steins;Gate", titleJP: "シュタインズ・ゲート",
    score: 9.07, members: 2900000, episodes: 24, status: "Finished", season: "Spring 2011",
    studio: "White Fox", genre: ["Sci-Fi","Thriller","Drama"], year: 2011,
    synopsis: "A self-proclaimed mad scientist discovers time travel and must struggle with the consequences of altering the past.",
    cover: "https://picsum.photos/seed/steinsgate/400/560",
    banner: "https://picsum.photos/seed/steinsbanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=27OZc-ku6is",
    ytSearch: "https://www.youtube.com/results?search_query=Steins+Gate+official+trailer",
    social: {
      mal: "https://myanimelist.net/anime/9253",
      anilist: "https://anilist.co/anime/9253",
      twitter: "https://twitter.com/search?q=SteinsGate+anime",
      instagram: "https://www.instagram.com/explore/tags/steinsgate/",
      tiktok: "https://www.tiktok.com/search?q=Steins+Gate+anime",
      facebook: "https://www.facebook.com/search/top?q=Steins+Gate+anime",
      reddit: "https://www.reddit.com/r/steinsgate/",
      youtube: "https://www.youtube.com/results?search_query=Steins+Gate+anime",
    },
    trending: false, newRelease: false, featured: false,
    badge: "⚡ Time Travel Classic", color: "#00e5ff",
  },
  {
    id: 4, rank: 4, title: "Attack on Titan: The Final Season", titleJP: "進撃の巨人",
    score: 9.05, members: 3800000, episodes: 87, status: "Finished", season: "Winter 2022",
    studio: "MAPPA", genre: ["Action","Drama","Dark Fantasy"], year: 2013,
    synopsis: "Humanity's last survivors battle monstrous Titans behind giant walls — until the truth of their world is revealed.",
    cover: "https://picsum.photos/seed/aot2024/400/560",
    banner: "https://picsum.photos/seed/aotbanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=MGRm4IzK1SQ",
    ytSearch: "https://www.youtube.com/results?search_query=Attack+on+Titan+Final+Season+trailer",
    social: {
      mal: "https://myanimelist.net/anime/51009",
      anilist: "https://anilist.co/anime/131681",
      twitter: "https://twitter.com/search?q=AttackonTitan+anime",
      instagram: "https://www.instagram.com/explore/tags/attackontitan/",
      tiktok: "https://www.tiktok.com/search?q=Attack+on+Titan",
      facebook: "https://www.facebook.com/AttackOnTitan/",
      reddit: "https://www.reddit.com/r/titanfolk/",
      youtube: "https://www.youtube.com/@AttackonTitan",
    },
    trending: true, newRelease: false, featured: false,
    badge: "🔥 Cultural Phenomenon", color: "#ff6b8a",
  },
  {
    id: 5, rank: 5, title: "Hunter x Hunter (2011)", titleJP: "ハンター×ハンター",
    score: 9.04, members: 3200000, episodes: 148, status: "Finished", season: "Fall 2011",
    studio: "Madhouse", genre: ["Action","Adventure","Fantasy"], year: 2011,
    synopsis: "Gon Freecss discovers his father is a legendary Hunter and sets out to become one himself.",
    cover: "https://picsum.photos/seed/hxh2011/400/560",
    banner: "https://picsum.photos/seed/hxhbanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=D3lTSdtGBaw",
    ytSearch: "https://www.youtube.com/results?search_query=Hunter+x+Hunter+2011+trailer",
    social: {
      mal: "https://myanimelist.net/anime/11061",
      anilist: "https://anilist.co/anime/11061",
      twitter: "https://twitter.com/search?q=HunterxHunter+anime",
      instagram: "https://www.instagram.com/explore/tags/hunterxhunter/",
      tiktok: "https://www.tiktok.com/search?q=Hunter+x+Hunter",
      facebook: "https://www.facebook.com/search/top?q=Hunter+x+Hunter+anime",
      reddit: "https://www.reddit.com/r/HunterXHunter/",
      youtube: "https://www.youtube.com/results?search_query=Hunter+x+Hunter+official",
    },
    trending: false, newRelease: false, featured: false,
    badge: "💎 Masterpiece", color: "#69ff8a",
  },
  {
    id: 6, rank: 6, title: "Vinland Saga Season 2", titleJP: "ヴィンランド・サガ",
    score: 8.98, members: 980000, episodes: 24, status: "Finished", season: "Winter 2023",
    studio: "MAPPA", genre: ["Action","Adventure","Historical"], year: 2023,
    synopsis: "Former Viking warrior Thorfinn seeks redemption and a land of peace — the mythical Vinland.",
    cover: "https://picsum.photos/seed/vinlandsaga2/400/560",
    banner: "https://picsum.photos/seed/vinlandbanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=B1eJQPGvs3c",
    ytSearch: "https://www.youtube.com/results?search_query=Vinland+Saga+Season+2+trailer",
    social: {
      mal: "https://myanimelist.net/anime/49387",
      anilist: "https://anilist.co/anime/137671",
      twitter: "https://twitter.com/search?q=VinlandSaga+anime",
      instagram: "https://www.instagram.com/explore/tags/vinlandsaga/",
      tiktok: "https://www.tiktok.com/search?q=Vinland+Saga",
      facebook: "https://www.facebook.com/search/top?q=Vinland+Saga+anime",
      reddit: "https://www.reddit.com/r/VinlandSaga/",
      youtube: "https://www.youtube.com/results?search_query=Vinland+Saga+MAPPA+official",
    },
    trending: false, newRelease: false, featured: false,
    badge: "⚔️ Epic Journey", color: "#ffa94d",
  },
  {
    id: 7, rank: 7, title: "Demon Slayer: Kimetsu no Yaiba", titleJP: "鬼滅の刃",
    score: 8.95, members: 3600000, episodes: 26, status: "Ongoing", season: "Spring 2019",
    studio: "ufotable", genre: ["Action","Fantasy","Dark Fantasy"], year: 2019,
    synopsis: "Tanjiro Kamado joins the Demon Slayer Corps to find a cure for his sister, transformed into a demon.",
    cover: "https://picsum.photos/seed/demonslayer/400/560",
    banner: "https://picsum.photos/seed/demonbanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=VXDUMGhUMkQ",
    ytSearch: "https://www.youtube.com/results?search_query=Demon+Slayer+Kimetsu+no+Yaiba+official+trailer",
    social: {
      mal: "https://myanimelist.net/anime/38000",
      anilist: "https://anilist.co/anime/101922",
      twitter: "https://twitter.com/kimetsu_off",
      instagram: "https://www.instagram.com/demonslayer.anime/",
      tiktok: "https://www.tiktok.com/search?q=Demon+Slayer+anime",
      facebook: "https://www.facebook.com/DemonSlayerAnime/",
      reddit: "https://www.reddit.com/r/KimetsuNoYaiba/",
      youtube: "https://www.youtube.com/@AniplexUSA",
    },
    trending: true, newRelease: false, featured: false,
    badge: "🌟 Global Hit", color: "#ff4daa",
  },
  {
    id: 8, rank: 8, title: "Jujutsu Kaisen", titleJP: "呪術廻戦",
    score: 8.72, members: 3100000, episodes: 24, status: "Ongoing", season: "Fall 2020",
    studio: "MAPPA", genre: ["Action","Dark Fantasy","Supernatural"], year: 2020,
    synopsis: "Yuji Itadori joins a secret organization to defeat Cursed Spirits after swallowing the finger of Ryomen Sukuna.",
    cover: "https://picsum.photos/seed/jjk2020/400/560",
    banner: "https://picsum.photos/seed/jjkbanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=pkKu9hLT-t8",
    ytSearch: "https://www.youtube.com/results?search_query=Jujutsu+Kaisen+official+trailer",
    social: {
      mal: "https://myanimelist.net/anime/40748",
      anilist: "https://anilist.co/anime/113415",
      twitter: "https://twitter.com/search?q=JujutsuKaisen+anime",
      instagram: "https://www.instagram.com/explore/tags/jujutsukaisen/",
      tiktok: "https://www.tiktok.com/search?q=Jujutsu+Kaisen",
      facebook: "https://www.facebook.com/search/top?q=Jujutsu+Kaisen+anime",
      reddit: "https://www.reddit.com/r/Jujutsushi/",
      youtube: "https://www.youtube.com/@jujutsukaisen_official",
    },
    trending: true, newRelease: false, featured: false,
    badge: "💥 Gen Z Favourite", color: "#7b61ff",
  },
  {
    id: 9, rank: 9, title: "Solo Leveling", titleJP: "俺だけレベルアップな件",
    score: 8.68, members: 1500000, episodes: 12, status: "Ongoing", season: "Winter 2024",
    studio: "A-1 Pictures", genre: ["Action","Fantasy","Isekai"], year: 2024,
    synopsis: "The world's weakest hunter Sung Jinwoo discovers a hidden system that allows only him to level up endlessly.",
    cover: "https://picsum.photos/seed/sololevel/400/560",
    banner: "https://picsum.photos/seed/solobanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=BO8YJZW7hdc",
    ytSearch: "https://www.youtube.com/results?search_query=Solo+Leveling+anime+official+trailer",
    social: {
      mal: "https://myanimelist.net/anime/57334",
      anilist: "https://anilist.co/anime/167944",
      twitter: "https://twitter.com/search?q=SoloLeveling+anime",
      instagram: "https://www.instagram.com/explore/tags/sololeveling/",
      tiktok: "https://www.tiktok.com/search?q=Solo+Leveling+anime",
      facebook: "https://www.facebook.com/search/top?q=Solo+Leveling+anime",
      reddit: "https://www.reddit.com/r/sololeveling/",
      youtube: "https://www.youtube.com/@sololeveling_anime",
    },
    trending: true, newRelease: true, featured: false,
    badge: "⚡ 2024 Breakout", color: "#00e5ff",
  },
  {
    id: 10, rank: 10, title: "Dungeon Meshi (Delicious in Dungeon)", titleJP: "ダンジョン飯",
    score: 8.65, members: 900000, episodes: 24, status: "Ongoing", season: "Winter 2024",
    studio: "Trigger", genre: ["Fantasy","Comedy","Adventure"], year: 2024,
    synopsis: "An adventuring party learns to cook and eat dungeon monsters to survive their quest.",
    cover: "https://picsum.photos/seed/dungeonmeshi/400/560",
    banner: "https://picsum.photos/seed/dungeonbanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=AeYJAsvTRgg",
    ytSearch: "https://www.youtube.com/results?search_query=Dungeon+Meshi+Delicious+in+Dungeon+trailer",
    social: {
      mal: "https://myanimelist.net/anime/52701",
      anilist: "https://anilist.co/anime/153518",
      twitter: "https://twitter.com/search?q=DungeonMeshi+anime",
      instagram: "https://www.instagram.com/explore/tags/dungeonmeshi/",
      tiktok: "https://www.tiktok.com/search?q=Delicious+in+Dungeon",
      facebook: "https://www.facebook.com/search/top?q=Dungeon+Meshi+anime",
      reddit: "https://www.reddit.com/r/DungeonMeshi/",
      youtube: "https://www.youtube.com/results?search_query=Dungeon+Meshi+official",
    },
    trending: true, newRelease: true, featured: false,
    badge: "🍳 Viral Sensation", color: "#ff9d4d",
  },
  {
    id: 11, rank: 11, title: "One Piece", titleJP: "ワンピース",
    score: 8.60, members: 5200000, episodes: 1100, status: "Ongoing", season: "Fall 1999",
    studio: "Toei Animation", genre: ["Action","Adventure","Comedy"], year: 1999,
    synopsis: "Monkey D. Luffy sails the seas with his pirate crew searching for the ultimate treasure: the One Piece.",
    cover: "https://picsum.photos/seed/onepiece2024/400/560",
    banner: "https://picsum.photos/seed/onepiecebanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=6X9f-WnhE-E",
    ytSearch: "https://www.youtube.com/results?search_query=One+Piece+anime+official",
    social: {
      mal: "https://myanimelist.net/anime/21",
      anilist: "https://anilist.co/anime/21",
      twitter: "https://twitter.com/search?q=OnePiece+anime",
      instagram: "https://www.instagram.com/explore/tags/onepiece/",
      tiktok: "https://www.tiktok.com/search?q=One+Piece+anime",
      facebook: "https://www.facebook.com/OnePieceAnime/",
      reddit: "https://www.reddit.com/r/OnePiece/",
      youtube: "https://www.youtube.com/@onepieceanime_official",
    },
    trending: true, newRelease: false, featured: false,
    badge: "🏴‍☠️ #1 Longest Legend", color: "#ff4d4d",
  },
  {
    id: 12, rank: 12, title: "Dragon Ball Z", titleJP: "ドラゴンボールZ",
    score: 8.14, members: 4800000, episodes: 291, status: "Finished", season: "1989",
    studio: "Toei Animation", genre: ["Action","Adventure","Martial Arts"], year: 1989,
    synopsis: "Goku and his friends defend Earth against ever-growing alien threats in the ultimate battle anime.",
    cover: "https://picsum.photos/seed/dbz1989/400/560",
    banner: "https://picsum.photos/seed/dbzbanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=0aW-G-9bkCo",
    ytSearch: "https://www.youtube.com/results?search_query=Dragon+Ball+Z+official+trailer",
    social: {
      mal: "https://myanimelist.net/anime/813",
      anilist: "https://anilist.co/anime/813",
      twitter: "https://twitter.com/dragonball_web",
      instagram: "https://www.instagram.com/dragonball/",
      tiktok: "https://www.tiktok.com/search?q=Dragon+Ball+Z",
      facebook: "https://www.facebook.com/DragonBallZ/",
      reddit: "https://www.reddit.com/r/dbz/",
      youtube: "https://www.youtube.com/@dragonballofficial",
    },
    trending: false, newRelease: false, featured: false,
    badge: "⭐ The OG", color: "#ffd966",
  },
  {
    id: 13, rank: 13, title: "Naruto: Shippuden", titleJP: "NARUTO疾風伝",
    score: 8.08, members: 5500000, episodes: 500, status: "Finished", season: "Spring 2007",
    studio: "Pierrot", genre: ["Action","Adventure","Ninja"], year: 2007,
    synopsis: "Naruto Uzumaki grows from an outcast ninja into the hero who will protect his village at all costs.",
    cover: "https://picsum.photos/seed/narutoshippuden/400/560",
    banner: "https://picsum.photos/seed/narutobanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=k0VKBTS5hAk",
    ytSearch: "https://www.youtube.com/results?search_query=Naruto+Shippuden+official",
    social: {
      mal: "https://myanimelist.net/anime/1735",
      anilist: "https://anilist.co/anime/1735",
      twitter: "https://twitter.com/NARUTOofficial",
      instagram: "https://www.instagram.com/naruto/",
      tiktok: "https://www.tiktok.com/search?q=Naruto+Shippuden",
      facebook: "https://www.facebook.com/Naruto/",
      reddit: "https://www.reddit.com/r/Naruto/",
      youtube: "https://www.youtube.com/@Naruto",
    },
    trending: false, newRelease: false, featured: false,
    badge: "🍥 Generation Icon", color: "#ff8c42",
  },
  {
    id: 14, rank: 14, title: "Chainsaw Man", titleJP: "チェンソーマン",
    score: 8.56, members: 2200000, episodes: 12, status: "Ongoing", season: "Fall 2022",
    studio: "MAPPA", genre: ["Action","Dark Fantasy","Horror"], year: 2022,
    synopsis: "Impoverished Denji merges with his demon dog Pochita to become Chainsaw Man — a government-sponsored devil hunter.",
    cover: "https://picsum.photos/seed/chainsawman2/400/560",
    banner: "https://picsum.photos/seed/chainsawbanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=q4Esij_JBuU",
    ytSearch: "https://www.youtube.com/results?search_query=Chainsaw+Man+anime+official+trailer",
    social: {
      mal: "https://myanimelist.net/anime/44511",
      anilist: "https://anilist.co/anime/127230",
      twitter: "https://twitter.com/chainsawman_PR",
      instagram: "https://www.instagram.com/explore/tags/chainsawman/",
      tiktok: "https://www.tiktok.com/search?q=Chainsaw+Man+anime",
      facebook: "https://www.facebook.com/search/top?q=Chainsaw+Man+anime",
      reddit: "https://www.reddit.com/r/Chainsawman/",
      youtube: "https://www.youtube.com/results?search_query=Chainsaw+Man+MAPPA+official",
    },
    trending: true, newRelease: false, featured: false,
    badge: "🔥 MAPPA Masterpiece", color: "#ff4d4d",
  },
  {
    id: 15, rank: 15, title: "Re:Zero − Starting Life in Another World", titleJP: "Re:ゼロから始める異世界生活",
    score: 8.30, members: 2800000, episodes: 25, status: "Ongoing", season: "Spring 2016",
    studio: "White Fox", genre: ["Isekai","Fantasy","Psychological"], year: 2016,
    synopsis: "Subaru is transported to a fantasy world and discovers he can return to life after death — bearing all the suffering.",
    cover: "https://picsum.photos/seed/rezero2016/400/560",
    banner: "https://picsum.photos/seed/rezerobanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=ZtVXMHCqCAQ",
    ytSearch: "https://www.youtube.com/results?search_query=Re+Zero+anime+official+trailer",
    social: {
      mal: "https://myanimelist.net/anime/31240",
      anilist: "https://anilist.co/anime/21355",
      twitter: "https://twitter.com/search?q=ReZero+anime",
      instagram: "https://www.instagram.com/explore/tags/rezero/",
      tiktok: "https://www.tiktok.com/search?q=Re+Zero+anime",
      facebook: "https://www.facebook.com/search/top?q=Re+Zero+anime",
      reddit: "https://www.reddit.com/r/Re_Zero/",
      youtube: "https://www.youtube.com/results?search_query=Re+Zero+official+anime",
    },
    trending: false, newRelease: false, featured: false,
    badge: "💀 Return by Death", color: "#bf9fff",
  },
  {
    id: 16, rank: 16, title: "Spy × Family", titleJP: "スパイファミリー",
    score: 8.44, members: 1900000, episodes: 25, status: "Ongoing", season: "Spring 2022",
    studio: "Wit Studio / CloverWorks", genre: ["Action","Comedy","Family"], year: 2022,
    synopsis: "A spy, an assassin, and a telepath form a fake family — but their bonds become surprisingly real.",
    cover: "https://picsum.photos/seed/spyfamily/400/560",
    banner: "https://picsum.photos/seed/spybanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=mFphgF0HVMU",
    ytSearch: "https://www.youtube.com/results?search_query=Spy+x+Family+anime+trailer",
    social: {
      mal: "https://myanimelist.net/anime/50265",
      anilist: "https://anilist.co/anime/140960",
      twitter: "https://twitter.com/spyfamily_anime",
      instagram: "https://www.instagram.com/explore/tags/spyxfamily/",
      tiktok: "https://www.tiktok.com/search?q=Spy+x+Family+anime",
      facebook: "https://www.facebook.com/search/top?q=Spy+x+Family+anime",
      reddit: "https://www.reddit.com/r/SpyxFamily/",
      youtube: "https://www.youtube.com/results?search_query=Spy+x+Family+official+anime",
    },
    trending: true, newRelease: false, featured: false,
    badge: "💝 Family Fav", color: "#ff9d4d",
  },
  {
    id: 17, rank: 17, title: "Bocchi the Rock!", titleJP: "ぼっち・ざ・ろっく！",
    score: 9.00, members: 820000, episodes: 12, status: "Finished", season: "Fall 2022",
    studio: "CloverWorks", genre: ["Music","Comedy","Slice of Life"], year: 2022,
    synopsis: "An introverted girl who dreams of being a rock star joins a band and learns the messy truth of friendship.",
    cover: "https://picsum.photos/seed/bocchirock/400/560",
    banner: "https://picsum.photos/seed/bochibanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=Cl8WTgkTBok",
    ytSearch: "https://www.youtube.com/results?search_query=Bocchi+the+Rock+anime+trailer",
    social: {
      mal: "https://myanimelist.net/anime/47917",
      anilist: "https://anilist.co/anime/130003",
      twitter: "https://twitter.com/bocchi_anime",
      instagram: "https://www.instagram.com/explore/tags/bocchitherock/",
      tiktok: "https://www.tiktok.com/search?q=Bocchi+the+Rock",
      facebook: "https://www.facebook.com/search/top?q=Bocchi+the+Rock+anime",
      reddit: "https://www.reddit.com/r/BocchiTheRock/",
      youtube: "https://www.youtube.com/results?search_query=Bocchi+the+Rock+official",
    },
    trending: false, newRelease: false, featured: false,
    badge: "🎸 Viral Sleeper Hit", color: "#ff6bba",
  },
  {
    id: 18, rank: 18, title: "Neon Genesis Evangelion", titleJP: "新世紀エヴァンゲリオン",
    score: 8.50, members: 1800000, episodes: 26, status: "Finished", season: "Fall 1995",
    studio: "Gainax / Khara", genre: ["Mecha","Psychological","Sci-Fi"], year: 1995,
    synopsis: "Teenager Shinji pilots giant bio-mechs called Evangelions to protect humanity — at unimaginable psychological cost.",
    cover: "https://picsum.photos/seed/nge1995/400/560",
    banner: "https://picsum.photos/seed/evabanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=yXaZRVxAeKc",
    ytSearch: "https://www.youtube.com/results?search_query=Neon+Genesis+Evangelion+trailer",
    social: {
      mal: "https://myanimelist.net/anime/30",
      anilist: "https://anilist.co/anime/30",
      twitter: "https://twitter.com/search?q=Evangelion+anime",
      instagram: "https://www.instagram.com/explore/tags/evangelion/",
      tiktok: "https://www.tiktok.com/search?q=Neon+Genesis+Evangelion",
      facebook: "https://www.facebook.com/search/top?q=Neon+Genesis+Evangelion",
      reddit: "https://www.reddit.com/r/evangelion/",
      youtube: "https://www.youtube.com/@khara_inc",
    },
    trending: false, newRelease: false, featured: false,
    badge: "🔬 Psychological Legend", color: "#00e5ff",
  },
  {
    id: 19, rank: 19, title: "Cowboy Bebop", titleJP: "カウボーイビバップ",
    score: 8.76, members: 1700000, episodes: 26, status: "Finished", season: "Spring 1998",
    studio: "Sunrise", genre: ["Sci-Fi","Action","Neo-noir"], year: 1998,
    synopsis: "A crew of misfit bounty hunters travel the Solar System in 2071 chasing criminals and their pasts.",
    cover: "https://picsum.photos/seed/cowboybebop/400/560",
    banner: "https://picsum.photos/seed/beebopbanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=Cj9Hw3bfIcA",
    ytSearch: "https://www.youtube.com/results?search_query=Cowboy+Bebop+anime+trailer",
    social: {
      mal: "https://myanimelist.net/anime/1",
      anilist: "https://anilist.co/anime/1",
      twitter: "https://twitter.com/search?q=CowboyBebop+anime",
      instagram: "https://www.instagram.com/explore/tags/cowboybebop/",
      tiktok: "https://www.tiktok.com/search?q=Cowboy+Bebop+anime",
      facebook: "https://www.facebook.com/search/top?q=Cowboy+Bebop+anime",
      reddit: "https://www.reddit.com/r/cowboybebop/",
      youtube: "https://www.youtube.com/results?search_query=Cowboy+Bebop+official+anime",
    },
    trending: false, newRelease: false, featured: false,
    badge: "🎷 Timeless Art", color: "#ffd966",
  },
  {
    id: 20, rank: 20, title: "Bleach: Thousand-Year Blood War", titleJP: "BLEACH 千年血戦篇",
    score: 8.88, members: 1600000, episodes: 52, status: "Ongoing", season: "Fall 2022",
    studio: "Pierrot", genre: ["Action","Supernatural","Shonen"], year: 2022,
    synopsis: "Ichigo Kurosaki faces the Quincy empire in the final, most explosive arc of Bleach.",
    cover: "https://picsum.photos/seed/bleachtybw/400/560",
    banner: "https://picsum.photos/seed/bleachbanner/1200/400",
    trailer: "https://www.youtube.com/watch?v=BFoibOBcXQU",
    ytSearch: "https://www.youtube.com/results?search_query=Bleach+Thousand+Year+Blood+War+trailer",
    social: {
      mal: "https://myanimelist.net/anime/41467",
      anilist: "https://anilist.co/anime/142838",
      twitter: "https://twitter.com/search?q=BleachTYBW",
      instagram: "https://www.instagram.com/explore/tags/bleach_tybw/",
      tiktok: "https://www.tiktok.com/search?q=Bleach+TYBW",
      facebook: "https://www.facebook.com/search/top?q=Bleach+Thousand+Year+Blood+War",
      reddit: "https://www.reddit.com/r/bleach/",
      youtube: "https://www.youtube.com/results?search_query=Bleach+TYBW+official+trailer",
    },
    trending: true, newRelease: false, featured: false,
    badge: "⚡ BIG 3 Returns", color: "#7b61ff",
  },
];

const SEASONS = [
  { name: "Winter 2025", anime: [9,10,17], color: "#00e5ff" },
  { name: "Fall 2024", anime: [1,14,20], color: "#ffd966" },
  { name: "Summer 2024", anime: [4,7,8], color: "#ff6b8a" },
  { name: "Spring 2024", anime: [2,5,6], color: "#69ff8a" },
];

const SOCIAL_ICONS = {
  youtube: { label: "YouTube", bg: "#ff0000", icon: "▶" },
  twitter: { label: "X / Twitter", bg: "#1a1a1a", icon: "𝕏" },
  instagram: { label: "Instagram", bg: "linear-gradient(45deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888)", icon: "📸" },
  tiktok: { label: "TikTok", bg: "#010101", icon: "♪" },
  facebook: { label: "Facebook", bg: "#1877f2", icon: "f" },
  reddit: { label: "Reddit", bg: "#ff4500", icon: "●" },
  mal: { label: "MyAnimeList", bg: "#2e51a2", icon: "M" },
  anilist: { label: "AniList", bg: "#02a9ff", icon: "A" },
};

const TABS = ["🌍 World Rankings","🆕 New Releases","🔥 Trending","📺 Social Hub","🔍 All Anime"];

export default function AnimaWorld() {
  const [tab, setTab] = useState(0);
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState("");
  const [filterGenre, setFilterGenre] = useState("All");
  const [myList, setMyList] = useState({});
  const [toast, setToast] = useState(null);
  const [loaded, setLoaded] = useState(false);
  const toastRef = useRef();

  useEffect(() => {
    (async () => {
      try {
        const r = await window.storage.get("mylist_v2");
        if (r?.value) setMyList(JSON.parse(r.value));
      } catch {}
      setLoaded(true);
    })();
  }, []);

  useEffect(() => {
    if (!loaded) return;
    window.storage.set("mylist_v2", JSON.stringify(myList));
  }, [myList, loaded]);

  const addToList = (anime, status) => {
    setMyList(m => ({ ...m, [anime.id]: status }));
    showToast(`Added "${anime.title}" → ${status}`);
  };

  const showToast = (msg) => {
    setToast(msg);
    clearTimeout(toastRef.current);
    toastRef.current = setTimeout(() => setToast(null), 3000);
  };

  const allGenres = ["All", ...new Set(ANIME_DB.flatMap(a => a.genre))];

  const filtered = ANIME_DB
    .filter(a => filterGenre === "All" || a.genre.includes(filterGenre))
    .filter(a => !search || a.title.toLowerCase().includes(search.toLowerCase()) || a.titleJP.includes(search));

  const trending = ANIME_DB.filter(a => a.trending);
  const newReleases = ANIME_DB.filter(a => a.newRelease || a.status === "Ongoing").slice(0, 10);
  const featured = ANIME_DB[0];

  return (
    <div style={{ minHeight: "100vh", background: "#040810", color: "#e2e8f0", fontFamily: "'Outfit', 'Noto Sans JP', sans-serif", overflowX: "hidden" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=Noto+Sans+JP:wght@400;700&family=Black+Han+Sans&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        ::-webkit-scrollbar{width:5px;}::-webkit-scrollbar-track{background:#040810;}::-webkit-scrollbar-thumb{background:#1a2744;border-radius:3px;}
        a{text-decoration:none;}
        .tab-btn{background:none;border:none;cursor:pointer;font-family:'Outfit',sans-serif;font-size:13px;font-weight:600;transition:all 0.2s;padding:10px 18px;border-radius:8px;white-space:nowrap;}
        .tab-btn.active{background:rgba(255,255,255,0.08);color:#fff;}
        .tab-btn:not(.active){color:#4a5568;}
        .tab-btn:hover:not(.active){color:#8892b0;background:rgba(255,255,255,0.04);}
        .rank-card{background:linear-gradient(160deg,#0a1020 0%,#080d1a 100%);border:1px solid rgba(255,255,255,0.05);border-radius:14px;transition:all 0.3s;cursor:pointer;overflow:hidden;}
        .rank-card:hover{border-color:rgba(255,255,255,0.15);transform:translateX(4px);box-shadow:-4px 0 20px rgba(0,0,0,0.3);}
        .social-btn{display:inline-flex;align-items:center;gap:7px;padding:8px 14px;border-radius:8px;font-size:12px;font-weight:700;font-family:'Outfit',sans-serif;cursor:pointer;border:none;color:#fff;text-decoration:none;transition:all 0.2s;letter-spacing:0.02em;}
        .social-btn:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(0,0,0,0.4);}
        .anime-poster{border-radius:12px;overflow:hidden;cursor:pointer;transition:transform 0.3s;position:relative;}
        .anime-poster:hover{transform:scale(1.04);}
        .anime-poster:hover .poster-overlay{opacity:1;}
        .poster-overlay{position:absolute;inset:0;background:rgba(4,8,16,0.8);opacity:0;transition:opacity 0.3s;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:8px;}
        .add-btn{padding:7px 16px;border-radius:6px;font-size:11px;font-weight:700;font-family:'Outfit',sans-serif;cursor:pointer;border:1px solid rgba(255,255,255,0.2);background:rgba(255,255,255,0.08);color:#fff;transition:all 0.2s;white-space:nowrap;}
        .add-btn:hover{background:rgba(255,255,255,0.15);}
        .add-btn.active{background:rgba(105,255,138,0.15);border-color:rgba(105,255,138,0.4);color:#69ff8a;}
        .detail-panel{position:fixed;inset:0;background:rgba(4,8,16,0.9);backdrop-filter:blur(16px);z-index:999;overflow-y:auto;animation:fadeIn 0.3s;}
        @keyframes fadeIn{from{opacity:0;}to{opacity:1;}}
        @keyframes slideUp{from{opacity:0;transform:translateY(30px);}to{opacity:1;transform:translateY(0);}}
        .animate-up{animation:slideUp 0.4s ease both;}
        .score-ring{width:60px;height:60px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;}
        input{background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#e2e8f0;font-family:'Outfit',sans-serif;border-radius:8px;padding:10px 16px;outline:none;transition:border 0.2s;font-size:14px;}
        input:focus{border-color:rgba(99,179,237,0.5);}
        select{background:#0a1020;border:1px solid rgba(255,255,255,0.1);color:#e2e8f0;font-family:'Outfit',sans-serif;border-radius:8px;padding:10px 14px;outline:none;font-size:13px;}
        select option{background:#0a1020;}
        .hero-btn{display:inline-flex;align-items:center;gap:8px;padding:12px 24px;border-radius:10px;font-family:'Outfit',sans-serif;font-size:14px;font-weight:700;cursor:pointer;border:none;transition:all 0.2s;}
        .pill{font-size:10px;font-weight:700;padding:3px 9px;border-radius:100px;letter-spacing:0.1em;text-transform:uppercase;}
        .share-strip{display:flex;gap:8px;flex-wrap:wrap;padding:16px;background:rgba(255,255,255,0.02);border-radius:12px;border:1px solid rgba(255,255,255,0.05);}
        .toast{position:fixed;bottom:24px;right:24px;background:linear-gradient(135deg,#0a1020,#111827);border:1px solid rgba(99,179,237,0.3);border-radius:10px;padding:12px 20px;font-size:13px;font-weight:600;color:#63b3ed;z-index:9999;animation:slideUp 0.3s;box-shadow:0 8px 32px rgba(0,0,0,0.5);}
      `}</style>

      {/* BG */}
      <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}>
        <div style={{ position: "absolute", top: 0, left: "50%", transform: "translateX(-50%)", width: "100vw", height: "50vh", background: "radial-gradient(ellipse 80% 60% at 50% -10%, rgba(99,102,241,0.08) 0%, transparent 70%)" }} />
        <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.012 }}>
          <defs><pattern id="g" width="32" height="32" patternUnits="userSpaceOnUse"><path d="M32 0L0 0 0 32" fill="none" stroke="#fff" strokeWidth="0.5"/></pattern></defs>
          <rect width="100%" height="100%" fill="url(#g)" />
        </svg>
      </div>

      <div style={{ position: "relative", zIndex: 1 }}>
        {/* HEADER */}
        <header style={{ borderBottom: "1px solid rgba(255,255,255,0.05)", padding: "0 28px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 60, background: "rgba(4,8,16,0.9)", backdropFilter: "blur(20px)", position: "sticky", top: 0, zIndex: 100 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ background: "linear-gradient(135deg,#6366f1,#a855f7,#ec4899)", borderRadius: 10, width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontWeight: 900, color: "#fff" }}>A</div>
            <div>
              <div style={{ fontSize: 16, fontWeight: 900, color: "#fff", letterSpacing: "-0.03em" }}>ANIMAWORLD</div>
              <div style={{ fontSize: 9, color: "#4a5568", letterSpacing: "0.2em", textTransform: "uppercase", marginTop: -2 }}>Global Anime Discovery Hub</div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 4, overflowX: "auto" }}>
            {TABS.map((t, i) => (
              <button key={i} className={`tab-btn ${tab === i ? "active" : ""}`} onClick={() => setTab(i)}>{t}</button>
            ))}
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexShrink: 0 }}>
            <div style={{ fontSize: 11, color: "#4a5568", textAlign: "right" }}>
              <div style={{ color: "#69ff8a", fontWeight: 700 }}>LIVE</div>
              <div>{ANIME_DB.length} Titles</div>
            </div>
          </div>
        </header>

        {/* HERO BANNER */}
        <div style={{ position: "relative", height: 380, overflow: "hidden" }}>
          <img src={featured.banner} style={{ width: "100%", height: "100%", objectFit: "cover" }} alt="" />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(90deg, rgba(4,8,16,0.97) 0%, rgba(4,8,16,0.7) 50%, rgba(4,8,16,0.3) 100%)" }} />
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", padding: "0 48px" }}>
            <div style={{ maxWidth: 600 }} className="animate-up">
              <div style={{ display: "flex", gap: 10, marginBottom: 14, flexWrap: "wrap" }}>
                <span className="pill" style={{ background: "rgba(99,102,241,0.2)", color: "#a5b4fc", border: "1px solid rgba(99,102,241,0.3)" }}>🏆 #1 WORLDWIDE</span>
                <span className="pill" style={{ background: "rgba(236,72,153,0.15)", color: "#f9a8d4", border: "1px solid rgba(236,72,153,0.3)" }}>WINTER 2024</span>
                <span className="pill" style={{ background: "rgba(105,255,138,0.12)", color: "#69ff8a", border: "1px solid rgba(105,255,138,0.3)" }}>SCORE: {featured.score}</span>
              </div>
              <h1 style={{ fontSize: 44, fontWeight: 900, color: "#fff", letterSpacing: "-0.04em", lineHeight: 1.1, marginBottom: 6 }}>{featured.title}</h1>
              <p style={{ fontSize: 13, color: "#a0aec0", marginBottom: 6, fontWeight: 400 }}>{featured.titleJP} · {featured.studio} · {featured.episodes} Episodes</p>
              <p style={{ fontSize: 14, color: "#718096", maxWidth: 480, lineHeight: 1.6, marginBottom: 22 }}>{featured.synopsis}</p>
              <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                <a href={featured.trailer} target="_blank" rel="noopener noreferrer" className="hero-btn" style={{ background: "linear-gradient(135deg,#ff0000,#cc0000)", color: "#fff" }}>
                  ▶ Watch Trailer
                </a>
                <a href={featured.social.mal} target="_blank" rel="noopener noreferrer" className="hero-btn" style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.15)", color: "#e2e8f0" }}>
                  📊 MyAnimeList
                </a>
                <button className="hero-btn" onClick={() => addToList(featured, "Plan to Watch")} style={{ background: myList[featured.id] ? "rgba(105,255,138,0.15)" : "rgba(99,102,241,0.15)", border: `1px solid ${myList[featured.id] ? "rgba(105,255,138,0.4)" : "rgba(99,102,241,0.4)"}`, color: myList[featured.id] ? "#69ff8a" : "#a5b4fc" }}>
                  {myList[featured.id] ? "✓ In My List" : "+ My List"}
                </button>
              </div>
            </div>
          </div>
          <div style={{ position: "absolute", right: 48, bottom: 32, display: "flex", gap: 8 }}>
            {Object.entries(featured.social).slice(0, 4).map(([k, url]) => (
              <a key={k} href={url} target="_blank" rel="noopener noreferrer" className="social-btn" style={{ background: SOCIAL_ICONS[k]?.bg || "#333", fontSize: 11, padding: "6px 12px" }}>
                {SOCIAL_ICONS[k]?.icon} {SOCIAL_ICONS[k]?.label}
              </a>
            ))}
          </div>
        </div>

        {/* SCROLLING TICKER */}
        <div style={{ background: "linear-gradient(90deg,#6366f1,#a855f7,#ec4899)", padding: "8px 0", overflow: "hidden", whiteSpace: "nowrap" }}>
          <div style={{ display: "inline-block", animation: "marquee 30s linear infinite" }}>
            <style>{`@keyframes marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}`}</style>
            {[...ANIME_DB, ...ANIME_DB].map((a, i) => (
              <span key={i} style={{ marginRight: 60, fontSize: 12, fontWeight: 700, color: "rgba(255,255,255,0.9)", letterSpacing: "0.05em" }}>
                #{a.rank} {a.title} <span style={{ opacity: 0.6 }}>★{a.score}</span>
              </span>
            ))}
          </div>
        </div>

        <main style={{ maxWidth: 1400, margin: "0 auto", padding: "36px 28px" }}>

          {/* ─── WORLD RANKINGS ─── */}
          {tab === 0 && (
            <div className="animate-up">
              <SectionHeader title="🌍 World Anime Rankings" sub={`Top ${ANIME_DB.length} anime ranked by global score & community votes`} />
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                {ANIME_DB.sort((a, b) => a.rank - b.rank).map((a, i) => (
                  <RankCard key={a.id} a={a} i={i} myList={myList} onAdd={addToList} onClick={() => setSelected(a)} />
                ))}
              </div>
            </div>
          )}

          {/* ─── NEW RELEASES ─── */}
          {tab === 1 && (
            <div className="animate-up">
              <SectionHeader title="🆕 Worldwide New Releases" sub="Season-by-season global anime releases" />
              {SEASONS.map(season => (
                <div key={season.name} style={{ marginBottom: 48 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 20 }}>
                    <div style={{ width: 4, height: 24, background: season.color, borderRadius: 2 }} />
                    <h2 style={{ fontSize: 20, fontWeight: 800, color: "#fff" }}>{season.name}</h2>
                    <span style={{ fontSize: 12, color: "#4a5568" }}>{season.anime.length} titles</span>
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(180px,1fr))", gap: 16 }}>
                    {season.anime.map(id => {
                      const a = ANIME_DB.find(x => x.id === id);
                      if (!a) return null;
                      return <PosterCard key={a.id} a={a} myList={myList} onAdd={addToList} onClick={() => setSelected(a)} />;
                    })}
                    {ANIME_DB.filter(x => x.newRelease).slice(0, 2).map(a => (
                      <PosterCard key={a.id} a={a} myList={myList} onAdd={addToList} onClick={() => setSelected(a)} />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* ─── TRENDING ─── */}
          {tab === 2 && (
            <div className="animate-up">
              <SectionHeader title="🔥 Trending Worldwide" sub="What the world is watching right now across all platforms" />
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 20, marginBottom: 40 }}>
                {trending.map((a, i) => (
                  <TrendCard key={a.id} a={a} rank={i + 1} myList={myList} onAdd={addToList} onClick={() => setSelected(a)} />
                ))}
              </div>
              <SectionHeader title="📈 Most Watched This Week" sub="Engagement data across YouTube, Twitter, TikTok & AniList" />
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {ANIME_DB.sort((a, b) => b.members - a.members).slice(0, 8).map((a, i) => (
                  <div key={a.id} onClick={() => setSelected(a)} className="rank-card" style={{ padding: "14px 18px", display: "flex", alignItems: "center", gap: 16, cursor: "pointer" }}>
                    <span style={{ fontSize: 22, fontWeight: 900, color: i < 3 ? ["#ffd700","#c0c0c0","#cd7f32"][i] : "#2d3748", width: 32, textAlign: "center" }}>#{i + 1}</span>
                    <img src={a.cover} style={{ width: 42, height: 58, objectFit: "cover", borderRadius: 7 }} alt={a.title} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 15, fontWeight: 700, color: "#e2e8f0" }}>{a.title}</div>
                      <div style={{ fontSize: 12, color: "#4a5568", marginTop: 2 }}>{a.genre.join(" · ")}</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: 16, fontWeight: 800, color: "#ffd966" }}>{(a.members / 1000000).toFixed(1)}M</div>
                      <div style={{ fontSize: 10, color: "#4a5568", textTransform: "uppercase", letterSpacing: "0.08em" }}>Members</div>
                    </div>
                    <div style={{ background: "rgba(99,102,241,0.15)", border: "1px solid rgba(99,102,241,0.3)", borderRadius: 8, padding: "6px 14px" }}>
                      <span style={{ fontSize: 15, fontWeight: 800, color: "#a5b4fc" }}>★ {a.score}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ─── SOCIAL HUB ─── */}
          {tab === 3 && (
            <div className="animate-up">
              <SectionHeader title="📺 Social Media Hub" sub="All links to watch, follow & share every anime across all platforms worldwide" />
              <div style={{ display: "flex", gap: 10, marginBottom: 28, flexWrap: "wrap" }}>
                {Object.entries(SOCIAL_ICONS).map(([k, v]) => (
                  <span key={k} style={{ padding: "6px 14px", borderRadius: 8, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", fontSize: 12, fontWeight: 700, color: "#8892b0", display: "flex", alignItems: "center", gap: 6 }}>
                    {v.icon} {v.label}
                  </span>
                ))}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                {ANIME_DB.map(a => (
                  <SocialRow key={a.id} a={a} myList={myList} onAdd={addToList} onClick={() => setSelected(a)} />
                ))}
              </div>
            </div>
          )}

          {/* ─── ALL ANIME ─── */}
          {tab === 4 && (
            <div className="animate-up">
              <SectionHeader title="🔍 Complete Anime Database" sub={`${ANIME_DB.length} titles with full worldwide release data`} />
              <div style={{ display: "flex", gap: 12, marginBottom: 28, flexWrap: "wrap" }}>
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by title or Japanese name..." style={{ width: 280 }} />
                <select value={filterGenre} onChange={e => setFilterGenre(e.target.value)} style={{ width: 160 }}>
                  {allGenres.map(g => <option key={g}>{g}</option>)}
                </select>
                <span style={{ fontSize: 13, color: "#4a5568", alignSelf: "center" }}>{filtered.length} results</span>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(165px,1fr))", gap: 16 }}>
                {filtered.map(a => (
                  <PosterCard key={a.id} a={a} myList={myList} onAdd={addToList} onClick={() => setSelected(a)} />
                ))}
              </div>
            </div>
          )}
        </main>
      </div>

      {/* DETAIL PANEL */}
      {selected && (
        <DetailPanel a={selected} myList={myList} onAdd={addToList} onClose={() => setSelected(null)} />
      )}

      {/* TOAST */}
      {toast && <div className="toast">✓ {toast}</div>}
    </div>
  );
}

// ─── COMPONENTS ─────────────────────────────────────────────────────────────

function SectionHeader({ title, sub }) {
  return (
    <div style={{ marginBottom: 28 }}>
      <h2 style={{ fontSize: 26, fontWeight: 900, color: "#fff", letterSpacing: "-0.03em" }}>{title}</h2>
      {sub && <p style={{ fontSize: 13, color: "#4a5568", marginTop: 4 }}>{sub}</p>}
    </div>
  );
}

function RankCard({ a, i, myList, onAdd, onClick }) {
  const rankColors = ["#ffd700","#c0c0c0","#cd7f32"];
  return (
    <div className="rank-card" onClick={onClick} style={{ padding: "16px 18px", display: "flex", gap: 14, alignItems: "center" }}>
      <div style={{ width: 40, height: 40, borderRadius: "50%", background: i < 3 ? `rgba(${["255,215,0","192,192,192","205,127,50"][i]},0.15)` : "rgba(255,255,255,0.04)", border: `2px solid ${i < 3 ? rankColors[i] : "#1a2744"}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, fontWeight: 900, color: i < 3 ? rankColors[i] : "#2d3748", flexShrink: 0 }}>
        {a.rank}
      </div>
      <img src={a.cover} style={{ width: 44, height: 62, objectFit: "cover", borderRadius: 8, flexShrink: 0 }} alt={a.title} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 2 }}>
          <span style={{ fontSize: 14, fontWeight: 700, color: "#e2e8f0", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{a.title}</span>
        </div>
        <div style={{ fontSize: 11, color: "#4a5568", marginBottom: 5 }}>{a.studio} · {a.year} · {a.episodes} eps</div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {a.genre.slice(0, 2).map(g => (
            <span key={g} style={{ fontSize: 10, padding: "2px 7px", borderRadius: 100, background: "rgba(255,255,255,0.06)", color: "#718096", fontWeight: 600 }}>{g}</span>
          ))}
          <span style={{ fontSize: 10, padding: "2px 7px", borderRadius: 100, background: a.status === "Ongoing" ? "rgba(105,255,138,0.1)" : "rgba(255,255,255,0.04)", color: a.status === "Ongoing" ? "#69ff8a" : "#4a5568", fontWeight: 600 }}>{a.status}</span>
        </div>
      </div>
      <div style={{ textAlign: "right", flexShrink: 0 }}>
        <div style={{ fontSize: 20, fontWeight: 900, color: "#ffd966" }}>{a.score}</div>
        <div style={{ fontSize: 10, color: "#4a5568", marginBottom: 6 }}>{(a.members / 1000000).toFixed(1)}M</div>
        <button className={`add-btn ${myList[a.id] ? "active" : ""}`} onClick={e => { e.stopPropagation(); onAdd(a, "Plan to Watch"); }} style={{ fontSize: 10, padding: "4px 10px" }}>
          {myList[a.id] ? "✓ Added" : "+ List"}
        </button>
      </div>
    </div>
  );
}

function PosterCard({ a, myList, onAdd, onClick }) {
  return (
    <div className="anime-poster" onClick={onClick} style={{ aspectRatio: "2/3" }}>
      <img src={a.cover} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} alt={a.title} />
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg,transparent 50%,rgba(4,8,16,0.97) 100%)" }} />
      {a.rank <= 5 && (
        <div style={{ position: "absolute", top: 8, left: 8, background: "rgba(0,0,0,0.75)", color: "#ffd966", fontSize: 11, fontWeight: 800, padding: "3px 8px", borderRadius: 6 }}>#{a.rank}</div>
      )}
      <div className="poster-overlay">
        <button className={`add-btn ${myList[a.id] ? "active" : ""}`} onClick={e => { e.stopPropagation(); onAdd(a, "Plan to Watch"); }}>
          {myList[a.id] ? "✓ In My List" : "+ Add to List"}
        </button>
        <a href={a.ytSearch} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()} className="add-btn" style={{ background: "rgba(255,0,0,0.2)", borderColor: "rgba(255,0,0,0.4)", color: "#ff6b6b" }}>
          ▶ Trailer
        </a>
      </div>
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: "10px 10px 12px" }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: "#e2e8f0", lineHeight: 1.3 }}>{a.title}</div>
        <div style={{ fontSize: 10, color: "#718096", marginTop: 2, display: "flex", justifyContent: "space-between" }}>
          <span>{a.year}</span>
          <span style={{ color: "#ffd966" }}>★{a.score}</span>
        </div>
      </div>
    </div>
  );
}

function TrendCard({ a, rank, myList, onAdd, onClick }) {
  const colors = ["#ec4899","#6366f1","#f97316","#10b981","#f59e0b","#8b5cf6","#06b6d4","#ef4444"];
  const color = colors[(rank - 1) % colors.length];
  return (
    <div onClick={onClick} style={{ background: "linear-gradient(145deg,#0a1020,#080d1a)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 16, overflow: "hidden", cursor: "pointer", transition: "all 0.3s" }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = color + "40"; e.currentTarget.style.transform = "translateY(-4px)"; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.06)"; e.currentTarget.style.transform = "translateY(0)"; }}>
      <div style={{ position: "relative", height: 200 }}>
        <img src={a.cover} style={{ width: "100%", height: "100%", objectFit: "cover" }} alt={a.title} />
        <div style={{ position: "absolute", inset: 0, background: `linear-gradient(180deg,transparent 30%,rgba(8,13,26,0.98) 100%)` }} />
        <div style={{ position: "absolute", top: 12, left: 12, width: 36, height: 36, borderRadius: "50%", background: color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, fontWeight: 900, color: "#fff" }}>#{rank}</div>
        <div style={{ position: "absolute", top: 12, right: 12 }}>
          <span style={{ background: "rgba(0,0,0,0.75)", color: "#ffd966", fontSize: 13, fontWeight: 800, padding: "4px 10px", borderRadius: 8 }}>★ {a.score}</span>
        </div>
      </div>
      <div style={{ padding: "14px 16px 16px" }}>
        <div style={{ fontSize: 15, fontWeight: 800, color: "#fff", marginBottom: 4 }}>{a.title}</div>
        <div style={{ fontSize: 11, color: "#4a5568", marginBottom: 10 }}>{a.genre.join(" · ")}</div>
        <div style={{ display: "flex", gap: 8 }}>
          <a href={a.ytSearch} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()} className="social-btn" style={{ background: "#ff0000", flex: 1, justifyContent: "center", fontSize: 11, padding: "7px 0" }}>
            ▶ YouTube
          </a>
          <a href={a.social.mal} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()} className="social-btn" style={{ background: "#2e51a2", flex: 1, justifyContent: "center", fontSize: 11, padding: "7px 0" }}>
            M MAL
          </a>
          <button className={`add-btn ${myList[a.id] ? "active" : ""}`} onClick={e => { e.stopPropagation(); onAdd(a, "Plan to Watch"); }}>
            {myList[a.id] ? "✓" : "+"}
          </button>
        </div>
      </div>
    </div>
  );
}

function SocialRow({ a, myList, onAdd, onClick }) {
  return (
    <div style={{ background: "linear-gradient(135deg,#0a1020,#080d1a)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 14, padding: "16px 20px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 14, cursor: "pointer" }} onClick={onClick}>
        <img src={a.cover} style={{ width: 50, height: 70, objectFit: "cover", borderRadius: 9, flexShrink: 0 }} alt={a.title} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 3 }}>
            <span style={{ fontSize: 16, fontWeight: 800, color: "#fff" }}>{a.title}</span>
            <span style={{ fontSize: 11, color: "#4a5568" }}>{a.titleJP}</span>
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <span style={{ fontSize: 12, color: "#ffd966", fontWeight: 700 }}>★ {a.score}</span>
            <span style={{ fontSize: 12, color: "#4a5568" }}>·</span>
            <span style={{ fontSize: 12, color: "#4a5568" }}>Rank #{a.rank}</span>
            <span style={{ fontSize: 12, color: "#4a5568" }}>·</span>
            <span style={{ fontSize: 12, color: "#4a5568" }}>{(a.members / 1000000).toFixed(1)}M members</span>
            <span className="pill" style={{ background: a.status === "Ongoing" ? "rgba(105,255,138,0.1)" : "rgba(255,255,255,0.05)", color: a.status === "Ongoing" ? "#69ff8a" : "#4a5568", border: "1px solid transparent" }}>{a.status}</span>
          </div>
          <div style={{ fontSize: 12, color: "#718096", marginTop: 4, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{a.synopsis.slice(0, 90)}...</div>
        </div>
        <button className={`add-btn ${myList[a.id] ? "active" : ""}`} onClick={e => { e.stopPropagation(); onAdd(a, "Plan to Watch"); }} style={{ flexShrink: 0 }}>
          {myList[a.id] ? "✓ Added" : "+ My List"}
        </button>
      </div>
      <div className="share-strip">
        {Object.entries(a.social).map(([k, url]) => {
          const cfg = SOCIAL_ICONS[k];
          if (!cfg) return null;
          return (
            <a key={k} href={url} target="_blank" rel="noopener noreferrer" className="social-btn" style={{ background: cfg.bg, fontSize: 11, padding: "6px 12px" }}>
              <span>{cfg.icon}</span> {cfg.label}
            </a>
          );
        })}
        <a href={a.ytSearch} target="_blank" rel="noopener noreferrer" className="social-btn" style={{ background: "linear-gradient(135deg,#ff0000,#cc0000)", fontSize: 11, padding: "6px 12px", marginLeft: "auto" }}>
          🎬 Watch Trailer
        </a>
      </div>
    </div>
  );
}

function DetailPanel({ a, myList, onAdd, onClose }) {
  return (
    <div className="detail-panel">
      <div style={{ maxWidth: 900, margin: "0 auto", padding: "32px 28px" }}>
        <button onClick={onClose} style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "#8892b0", cursor: "pointer", borderRadius: 8, padding: "8px 16px", marginBottom: 24, fontFamily: "'Outfit',sans-serif", fontSize: 13, fontWeight: 600 }}>
          ← Back
        </button>
        <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", gap: 32 }}>
          <div>
            <div style={{ borderRadius: 16, overflow: "hidden", marginBottom: 16, boxShadow: "0 20px 60px rgba(0,0,0,0.6)" }}>
              <img src={a.cover} style={{ width: "100%", display: "block" }} alt={a.title} />
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {[["Score","★ " + a.score,"#ffd966"],["Rank","#" + a.rank,"#a5b4fc"],["Members",(a.members/1000000).toFixed(1)+"M","#69ff8a"],["Episodes",a.episodes,"#e2e8f0"],["Status",a.status,a.status==="Ongoing"?"#69ff8a":"#718096"],["Studio",a.studio,"#e2e8f0"],["Year",a.year,"#e2e8f0"]].map(([l,v,c]) => (
                <div key={l} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                  <span style={{ fontSize: 12, color: "#4a5568", fontWeight: 500 }}>{l}</span>
                  <span style={{ fontSize: 12, fontWeight: 700, color: c }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div style={{ marginBottom: 4, fontSize: 13, color: "#4a5568" }}>{a.titleJP}</div>
            <h1 style={{ fontSize: 32, fontWeight: 900, color: "#fff", letterSpacing: "-0.03em", marginBottom: 8 }}>{a.title}</h1>
            <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
              <span className="pill" style={{ background: "rgba(99,102,241,0.15)", color: "#a5b4fc", border: "1px solid rgba(99,102,241,0.3)" }}>{a.badge}</span>
              {a.trending && <span className="pill" style={{ background: "rgba(236,72,153,0.1)", color: "#f9a8d4", border: "1px solid rgba(236,72,153,0.3)" }}>🔥 Trending</span>}
              {a.genre.map(g => <span key={g} className="pill" style={{ background: "rgba(255,255,255,0.05)", color: "#718096", border: "1px solid rgba(255,255,255,0.08)" }}>{g}</span>)}
            </div>
            <p style={{ fontSize: 14, color: "#a0aec0", lineHeight: 1.7, marginBottom: 24 }}>{a.synopsis}</p>

            <div style={{ display: "flex", gap: 10, marginBottom: 28, flexWrap: "wrap" }}>
              <a href={a.trailer} target="_blank" rel="noopener noreferrer" className="hero-btn" style={{ background: "#ff0000", color: "#fff" }}>▶ Watch Trailer</a>
              <a href={a.ytSearch} target="_blank" rel="noopener noreferrer" className="hero-btn" style={{ background: "rgba(255,0,0,0.15)", border: "1px solid rgba(255,0,0,0.3)", color: "#ff6b6b" }}>🔍 YouTube Search</a>
              <button className={`hero-btn ${myList[a.id] ? "active" : ""}`} onClick={() => onAdd(a, "Plan to Watch")} style={{ background: myList[a.id] ? "rgba(105,255,138,0.15)" : "rgba(255,255,255,0.06)", border: `1px solid ${myList[a.id] ? "rgba(105,255,138,0.4)" : "rgba(255,255,255,0.1)"}`, color: myList[a.id] ? "#69ff8a" : "#e2e8f0" }}>
                {myList[a.id] ? "✓ In My List" : "+ Add to My List"}
              </button>
            </div>

            <h3 style={{ fontSize: 14, fontWeight: 800, color: "#8892b0", letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 16 }}>All Social Platforms & Links</h3>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(150px,1fr))", gap: 10 }}>
              {Object.entries(a.social).map(([k, url]) => {
                const cfg = SOCIAL_ICONS[k];
                if (!cfg) return null;
                return (
                  <a key={k} href={url} target="_blank" rel="noopener noreferrer" className="social-btn" style={{ background: cfg.bg, justifyContent: "center", padding: "10px 14px" }}>
                    <span style={{ fontSize: 14 }}>{cfg.icon}</span>
                    <span style={{ fontSize: 11 }}>{cfg.label}</span>
                  </a>
                );
              })}
            </div>

            <div style={{ marginTop: 24, padding: 18, background: "rgba(99,102,241,0.08)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 12 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#a5b4fc", marginBottom: 10 }}>📣 Share & Drive Traffic</div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {[
                  { label: "Share on X", url: `https://twitter.com/intent/tweet?text=Watching+${encodeURIComponent(a.title)}+%23anime+%23${encodeURIComponent(a.title.replace(/\s/g,''))}&url=https://animaworld.app`, color: "#1a1a1a" },
                  { label: "Share on Facebook", url: `https://www.facebook.com/sharer/sharer.php?u=https://animaworld.app`, color: "#1877f2" },
                  { label: "Share on Reddit", url: `https://reddit.com/submit?title=${encodeURIComponent("Just watched "+a.title+" - "+a.score+"/10 score!")}&url=https://animaworld.app`, color: "#ff4500" },
                  { label: "Copy MAL Link", url: a.social.mal, color: "#2e51a2" },
                ].map(s => (
                  <a key={s.label} href={s.url} target="_blank" rel="noopener noreferrer" className="social-btn" style={{ background: s.color, fontSize: 11, padding: "7px 13px" }}>
                    {s.label}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
