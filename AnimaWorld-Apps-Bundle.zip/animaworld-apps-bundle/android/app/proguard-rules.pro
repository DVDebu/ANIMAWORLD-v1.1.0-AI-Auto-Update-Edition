# AnimaWorld ProGuard Rules

# Keep WebView JavaScript interface
-keepclassmembers class app.animaworld.AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep Activity
-keep class app.animaworld.** { *; }

# WebView
-keepclassmembers class * extends android.webkit.WebViewClient {
    public void *(android.webkit.WebView, java.lang.String, android.graphics.Bitmap);
    public boolean *(android.webkit.WebView, java.lang.String);
}

# General Android
-dontwarn android.webkit.**
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
